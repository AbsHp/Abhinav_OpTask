const personIcon = 0xe481; //person
const workIcon = 0xe11c; //work
const movieIcon = 0xe40f; //movie
const sportIcon = 0xe4dc; //sport
const travelIcon = 0xe071; //travel
const shopIcon = 0xe59c;
